#!/usr/bin/env python
# coding: utf-8

# In[97]:


import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import plot_confusion_matrix,classification_report,plot_precision_recall_curve,plot_roc_curve


# In[3]:


#Load The Data
df = pd.read_csv('bank-direct-marketing-campaigns.csv')
df.head()


# In[4]:


df.info()


# In[27]:


#print the categorical columns

for col in df.columns:
        if df[col].dtype == 'object':
            print(f'The column name is: {col} , The unique values are: {df[col].unique()}')
            print(f'  ')
        


# In[40]:


#Data Visualisation
# plotting graphs for all categorical columns

def categorical_columns(df):
    categorical_columns = [column_name for column_name in df if df[column_name].dtype == 'O']
    return categorical_columns

for col in categorical_columns(df):
    counts = df[col].value_counts().sort_index()
    if len(counts) > 10:
      fig = plt.figure(figsize=(30, 10))
    else:
      fig = plt.figure(figsize=(9, 6))
    ax = fig.gca()
    counts.plot.bar(ax = ax, color='steelblue')
    ax.set_title(col + ' counts')
    ax.set_xlabel(col) 
    ax.set_ylabel("Frequency")
plt.show()


# In[32]:


#imbalanced categorical data observed

#Visulasing according to the target y
plt.figure(figsize=(10,5))
sns.countplot(df['job'],hue=df['y'])
plt.xticks(rotation=90);


# In[34]:


plt.figure(figsize=(10,5))
sns.countplot(df['education'],hue=df['y'])
plt.xticks(rotation=90);


# In[36]:


plt.figure(figsize=(10,5))
sns.countplot(df['housing'],hue=df['y'])
plt.xticks(rotation=90);


# In[37]:


plt.figure(figsize=(10,5))
sns.countplot(df['loan'],hue=df['y'])
plt.xticks(rotation=90);


# In[44]:


#Draw histogram for each numerical columns
sns.histplot(df['emp.var.rate'],bins=5);


# In[45]:


sns.histplot(df['cons.price.idx'],bins=5);


# In[46]:


sns.histplot(df['euribor3m'],bins=5);


# In[47]:


sns.histplot(df['nr.employed'],bins=5);


# In[48]:


sns.histplot(df['cons.conf.idx'],bins=5);


# In[52]:


#Find the highly correlated columns
plt.figure(figsize=(12, 8))
sns.heatmap(df.corr(), annot=True, cmap='Reds')
plt.show()


# In[53]:


#Positive high correlation between:

#'emp.var.rate' and 'nr.employed'
#'emp.var.rate' and 'euribor3m'
#'euribor3m' and 'nr.employed'

#So I'll drop them
df.drop(['emp.var.rate', 'nr.employed', 'euribor3m'], axis=1, inplace = True)


# In[54]:


df.head()


# In[55]:


#I will drop the columns that will not affect the result
df.drop(['day_of_week', 'contact', 'month'], axis=1, inplace = True)


# In[56]:


df.head()


# In[65]:


#convert the catogeral to num and handling the unknown instances

cleanup_nums = {"y":     {"no": 0, "yes": 1},
                "job": {"housemaid": 0,
                       "services": 1,
                       "admin": 2,
                       "technician": 3,
                       "housemaid": 4,
                       "retired": 5,
                       "unemployed": 6,
                       "self-employed": 7,
                       "unknown": 8,
                       "management": 9,
                       "entrepreneur": 10,
                       "student": 11},
                "marital":{"married": 0,
                          "single": 1,
                          "divorced":2,
                          "unknown": 3},
                "education":{"basic.4y": 0,
                             "high.school": 1,
                             "basic.6y": 2,
                             "basic.9y": 3,
                             "university.degree": 4,
                             "professional.course": 5,
                             "unknown": 6,
                            "illiterate":7},
                "default":{"unknown": 0,
                           "no": 1,
                           "yes":2
                    
                },
                "housing":{"unknown":0, 
                          "no":1,
                          "yes":2},
                
                "loan":{"unknown":0, 
                          "no":1,
                          "yes":2},

                  "poutcome":{"nonexistent":0,
                             "failure": 1,
                             "success":2}}


# In[70]:


df = df.replace(cleanup_nums)
df.head()
df.info()


# In[101]:



#handling the imbalanced for the Y
#Using Under sampling beacuse the size is sufficient
x = df.drop("y", axis=1)
y = df['y']

x, y = SMOTE().fit_resample(x,y)
y_un,count = np.unique(y,return_counts=True)
plt.title("Class Balancing")
plt.xlabel("Class")
plt.ylabel("Count")
plt.bar([str(i) for i in y_un],count)
plt.show()


# In[102]:


#splitting the data into 80 -20
x_train,x_test,y_train,y_test = train_test_split(x,y, random_state=42)


# In[103]:


scaler=StandardScaler()
x_train=scaler.fit_transform(x_train)
x_test=scaler.transform(x_test)


# In[104]:


#Data Modling

#Logistic regression 

lr = LogisticRegression(random_state=1)
lr.fit(x_train, y_train)



#KNeighborsClassifier
knc_model=KNeighborsClassifier()
knc_model.fit(x_train,y_train)


#Random forest
rfc_model=RandomForestClassifier()
rfc_model.fit(x_train,y_train)


# In[105]:


def report(model):
    pred = model.predict(x_test)
    print(classification_report(pred,y_test))
    plot_confusion_matrix(model,x_test,y_test)
    plot_precision_recall_curve(model,x_test,y_test)
    plot_roc_curve(model,x_test,y_test)


# In[94]:



print("LOGISTIC REGRESSION MODEL")
report(lr)


# In[95]:


print("KNEIGHBORS CLASSIFIER MODEL")
report(knc_model)


# In[96]:


print("RANDOM FOREST CLASSIFIER MODEL")
report(rfc_model)


# In[ ]:




